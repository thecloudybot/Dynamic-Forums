<script type="text/javascript">

  var images = ['https://www.lovethispic.com/uploaded_images/20873-Trippy-Gif.gif?1'];
  document.getElementsByClassName('mainview')[0].style.backgroundImage = 'url(' + images[Math.floor(Math.random() * images.length)] + ')';

</script>